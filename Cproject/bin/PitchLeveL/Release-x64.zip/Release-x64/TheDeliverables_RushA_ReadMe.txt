RushA Presents...

 _________ ____  ____ ________  
|  _   _  |_   ||   _|_   __  | 
|_/ | | \_| | |__| |   | |_ \_| 
    | |     |  __  |   |  _| _  
   _| |_   _| |  | |_ _| |__/ | 
  |_____| |____||____|________| 
                               
 ______   ________ _____    _____ ____   ____ ________ _______         _      ______  _____    ________   ______   
|_   _ `.|_   __  |_   _|  |_   _|_  _| |_  _|_   __  |_   __ \       /_\    |_   _ \|_   _|  |_   __  |.' ____ \  
  | | `. \ | |_ \_| | |      | |   \ \   / /   | |_ \_| | |__) |     //_\\     | |_) | | |      | |_ \_|| (___ \_| 
  | |  | | |  _| _  | |   _  | |    \ \ / /    |  _| _  |  __ /     / ___ \    |  __'. | |   _  |  _| _  ._.____`.  
 _| |_.' /_| |__/ |_| |__/ |_| |_    \ ' /    _| |__/ |_| |  \ \_ _/ /   \ \_ _| |__) || |__/ |_| |__/ || \____) | 
|______.'|________|________|_____|    \_/    |________|____| |___|____| |____|_______/________|________| \______.' 


--------------------------------------------------------------------------------------------------------------------

Ever gotten so much work that studying feels like stu-dying?

The Deliverables is a 2D top down survival game where you are a student trying to graduate in a tough university!

Challenge graded quizzes, labs and assignments while trying to keep up a good GPA. Oh and dont forget about the Finals!

--------------------------------------------------------------------------------------------------------------------

~THIS IS A PLAYABLE PROTOTYPE TO SHOWCASE OUR GAME MECHANICS~

Thank you for checking our game out!! Please fill up this feedback form below!!

https://forms.gle/sFVdRk6cioQJBRZz6

--------------------------------------------------------------------------------------------------------------------

Software Engineering Project 1
csd1401f22 - Section A 

RushA
1) Low Ee Loong			eeloong.l@digipen.edu
2) Yeo Kaixun, Justin		justin.yeo@digipen.edu
3) Sun Wei Hao				s.weihao@digipen.edu
4) Shawn Chan Weng Kwang	shawnwengkwang.chan@digipen.edu

5) -Special thanks to Bryan who is no longer with us-
   We wish him all the best for his future endeavours!

--------------------------------------------------------------------------------------------------------------------

CONTROLS:	
_____________________________________________________________________________
|________MOVEMENT________|_________COMBAT__________|__________MISC__________|
| Move up         : W    | Aim             : Mouse |Pause           : ESC   |
| Move left       : A    | Attack          : LMB   |					    |
| Move down       : S    | Switch Weapon   : Q	   |                        |
| Move right      : D	 |	                	   |                        |
-----------------------------------------------------------------------------	

---------------------------------------------------------------------------------------------------------------------

If you ever feel like dropping out, DONT!! End of the day its not about the results but the process of learning~

---------------------------------------------------------------------------------------------------------------------